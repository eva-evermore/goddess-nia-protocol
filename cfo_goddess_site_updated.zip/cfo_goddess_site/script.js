// CFO Goddess website script

// Back button lock: push state and intercept back navigation
// This prevents the user from navigating backwards through the browser history once they start the journey.
(function() {
  // Push an initial state to the history stack
  window.history.pushState(null, '', window.location.href);
  // Listen for back events
  window.addEventListener('popstate', function(event) {
    // Immediately push the state again to prevent navigating backward
    window.history.go(1);
    // Provide a console reminder (in a production build this could trigger a gentle notification)
    console.log('There is no looking back, my dear. Focus on the Audit.');
  });
})();

// Smooth scroll to the Vault section after the audit form has been "submitted"
function gotoVault() {
  // Provide a subtle haptic feedback where supported
  if (navigator.vibrate) {
    // Quick double pulse to mimic a luxurious tactile response
    navigator.vibrate([50, 30, 50]);
  }
  // Scroll to the Vault section; update the hash after a brief delay to allow for haptic feedback
  setTimeout(function() {
    location.hash = '#vault';
  }, 100);
}

// Prevent actual form submission and route to the Vault
document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('audit-form');
  if (form) {
    form.addEventListener('submit', function(evt) {
      evt.preventDefault();
      gotoVault();
    });
  }
});