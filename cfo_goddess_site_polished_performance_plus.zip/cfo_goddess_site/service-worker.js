/* Simple offline cache for GitHub Pages-friendly static sites */
const CACHE_NAME = 'cfo-goddess-v4';
const ASSETS = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './manifest.json',
  './icon-192x192.png',
  './icon-512x512.png',
  './analytics.js',
  './favicon.ico',
  './favicon-32x32.png',
  './favicon-16x16.png',
  './apple-touch-icon.png',
  './img/og.jpg',
  './img/534d5c09-24f3-4f79-91d9-f0fecf4e8f91.png',
  './img/534d5c09-24f3-4f79-91d9-f0fecf4e8f91.webp',
  './img/94084EB9-32E6-4F8B-834A-48ECD2D471ED.jpeg',
  './img/94084EB9-32E6-4F8B-834A-48ECD2D471ED.webp',
  './img/garage.jpg',
  './img/garage.webp',
  './img/library.jpg',
  './img/library.webp',
  './img/pool.jpg',
  './img/pool.webp',
  './img/temp.jpg',
  './img/temp.webp',
  './img/vault.jpg',
  './img/vault.webp',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
        return res;
      }).catch(() => cached);
    })
  );
});
