/* 
  Privacy-friendly analytics hook (disabled by default)

  Option A: Plausible (recommended, cookieless)
  1) Create a Plausible account and add your site.
  2) Set enabled:true and update domain + scriptSrc below.
  3) Deploy.

  Option B: Umami (self-hosted)
  - Replace provider with 'umami' and set scriptSrc + websiteId.

  This file ships with the site so you can enable analytics by editing ONE place.
*/
window.CFO_ANALYTICS = {
  enabled: false,

  // 'plausible' | 'umami'
  provider: 'plausible',

  // Plausible settings
  domain: 'YOUR-DOMAIN-HERE',
  scriptSrc: 'https://plausible.io/js/script.js',

  // Umami settings (if used)
  websiteId: 'YOUR-UMAMI-WEBSITE-ID',
  umamiSrc: 'https://YOUR-UMAMI-HOST/script.js'
};
