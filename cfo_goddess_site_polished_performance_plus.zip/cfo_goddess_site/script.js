// CFO Goddess website script (polish + performance)

// Detect WebP support (sync, tiny)
function supportsWebp() {
  try {
    var c = document.createElement('canvas');
    return c.toDataURL('image/webp').indexOf('data:image/webp') === 0;
  } catch (e) {
    return false;
  }
}

var USE_WEBP = supportsWebp();
if (USE_WEBP) document.documentElement.classList.add('webp');

// Analytics loader + safe event tracking (privacy-friendly; optional)
var ANALYTICS_CFG = window.CFO_ANALYTICS || { enabled: false };
var analyticsReady = false;

function initAnalytics() {
  if (!ANALYTICS_CFG || !ANALYTICS_CFG.enabled) return;

  try {
    if (ANALYTICS_CFG.provider === 'plausible') {
      // Stub queue per Plausible docs
      window.plausible = window.plausible || function () {
        (window.plausible.q = window.plausible.q || []).push(arguments);
      };

      var s = document.createElement('script');
      s.defer = true;
      s.src = ANALYTICS_CFG.scriptSrc || 'https://plausible.io/js/script.js';
      if (ANALYTICS_CFG.domain) s.setAttribute('data-domain', ANALYTICS_CFG.domain);
      s.onload = function () { analyticsReady = true; };
      document.head.appendChild(s);
      analyticsReady = true; // queueing works even before load
    } else if (ANALYTICS_CFG.provider === 'umami') {
      var su = document.createElement('script');
      su.defer = true;
      su.src = ANALYTICS_CFG.umamiSrc || ANALYTICS_CFG.scriptSrc || '';
      if (ANALYTICS_CFG.websiteId) su.setAttribute('data-website-id', ANALYTICS_CFG.websiteId);
      su.onload = function () { analyticsReady = true; };
      document.head.appendChild(su);
    }
  } catch (e) {
    // analytics is strictly optional
  }
}

function trackEvent(name, props) {
  if (!ANALYTICS_CFG || !ANALYTICS_CFG.enabled) return;
  try {
    if (ANALYTICS_CFG.provider === 'plausible' && window.plausible) {
      window.plausible(name, props ? { props: props } : undefined);
    } else if (ANALYTICS_CFG.provider === 'umami' && window.umami && window.umami.track) {
      window.umami.track(name, props || {});
    }
  } catch (e) {}
}

// iOS detection for scroll-snap tuning
function isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}
if (isIOS()) document.documentElement.classList.add('ios');


// Optional tactile feedback helper
function luxeTap() {
  if (navigator.vibrate) navigator.vibrate([35, 25, 35]);
}

// Smooth route to a section (hash update)
function gotoSection(id) {
  var el = document.getElementById(id);
  if (!el) return;
  luxeTap();
  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  history.replaceState(null, '', '#' + id);
}

function gotoVault() { gotoSection('vault'); }

// Age gate (remembered locally)
function initAgeGate() {
  var key = 'cfo_goddess_age_ok_v1';
  var modal = document.getElementById('age-gate');
  if (!modal) return;

  var ok = localStorage.getItem(key) === '1';
  if (ok) return;

  document.body.classList.add('modal-open');
  modal.classList.add('show');
  modal.setAttribute('aria-hidden', 'false');

  var btn = document.getElementById('age-confirm');
  if (btn) {
    btn.addEventListener('click', function () {
      localStorage.setItem(key, '1');
      modal.classList.remove('show');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('modal-open');
      luxeTap();
      trackEvent('Age Gate Accepted');
    });
  }
}

// Lazy-load section backgrounds (avoids downloading every hero image at once)
function initLazyBackgrounds() {
  var root = document.querySelector('.app-shell') || null;
  var sections = Array.prototype.slice.call(document.querySelectorAll('section.hero[data-bg]'));
  if (!sections.length) return;

  function pickUrl(sec) {
    if (USE_WEBP && sec.dataset.bgWebp) return sec.dataset.bgWebp;
    return sec.dataset.bg;
  }

  function prefetch(url) {
    if (!url) return;
    var img = new Image();
    img.decoding = 'async';
    img.src = url;
  }

  function load(sec) {
    if (!sec || sec.dataset.bgLoaded === '1') return;
    var url = pickUrl(sec);
    sec.style.backgroundImage = "url('" + url + "')";
    sec.dataset.bgLoaded = '1';

    // Prefetch the next section's background for buttery scrolling
    var idx = sections.indexOf(sec);
    if (idx > -1 && sections[idx + 1]) {
      prefetch(pickUrl(sections[idx + 1]));
    }
  }

  // Load the first visible section immediately
  load(sections[0]);

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) load(entry.target);
    });
  }, { root: root, rootMargin: '320px 0px', threshold: 0.01 });

  sections.forEach(function (s) { io.observe(s); });
}

// Progress nav highlight
function initProgressNav() {
  var root = document.querySelector('.app-shell') || null;
  var nav = document.querySelector('.progress-nav');
  if (!nav) return;

  var links = Array.prototype.slice.call(nav.querySelectorAll('a[data-section]'));
  var map = {};
  links.forEach(function (a) { map[a.dataset.section] = a; });

  var lastActiveId = null;
  function setActive(id) {
    links.forEach(function (a) { a.classList.toggle('active', a.dataset.section === id); });
    if (id && id !== lastActiveId) {
      lastActiveId = id;
      trackEvent('Section View', { section: id });
    }
  }

  var sections = Array.prototype.slice.call(document.querySelectorAll('section.hero[id]'));

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) setActive(entry.target.id);
    });
  }, { root: root, threshold: 0.6 });

  sections.forEach(function (s) { io.observe(s); });

  // Gentle haptics on nav taps
  links.forEach(function (a) {
    a.addEventListener('click', function (evt) {
      luxeTap();
      // Smooth anchor scrolling inside the scroll container, with iOS snap-friendly handling
      try {
        var id = a.getAttribute('href').replace('#','');
        var el = document.getElementById(id);
        var shell = document.querySelector('.app-shell');
        if (evt) evt.preventDefault();
        if (!el) return;

        // Temporarily disable snap during programmatic scroll to avoid iOS "rubber-band snap"
        if (shell) {
          shell.classList.add('snap-paused');
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          setTimeout(function () { shell.classList.remove('snap-paused'); }, 700);
        } else {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        history.replaceState(null, '', '#' + id);
        trackEvent('Nav Click', { section: id });
      } catch (e) {}
    });
  });
}

// Audit form: validate the 16-digit ID and route forward
function initAuditForm() {
  var form = document.getElementById('audit-form');
  if (!form) return;

  var tx = document.getElementById('transactionId');
  var err = document.getElementById('audit-error');

  form.addEventListener('submit', function (evt) {
    evt.preventDefault();
    if (err) err.textContent = '';

    var val = (tx && tx.value ? tx.value : '').replace(/\s+/g, '');
    var ok = /^\d{16}$/.test(val);

    if (!ok) {
      if (err) err.textContent = 'Transaction ID must be exactly 16 digits.';
      if (tx) tx.focus();
      if (navigator.vibrate) navigator.vibrate(80);
      return;
    }

    // Normalize back into the field (no spaces)
    if (tx) tx.value = val;

    gotoVault();
  });
}

// Optional: register a tiny service worker for faster repeat visits
function initServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./service-worker.js').catch(function () { /* ignore */ });
  });
}

document.addEventListener('DOMContentLoaded', function () {
  initAnalytics();
  initAgeGate();
  initLazyBackgrounds();
  initProgressNav();
  initAuditForm();
  initServiceWorker();
});
